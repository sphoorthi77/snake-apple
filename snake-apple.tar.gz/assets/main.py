import pygame
import random
import sys
import asyncio

CELL       = 24
COLS       = 22
ROWS       = 18
WIDTH      = CELL * COLS
HEIGHT     = CELL * ROWS + 60
FPS_START  = 5
FPS_MAX    = 12

BG_DARK      = (14, 17, 22)
BG_GRID      = (22, 26, 34)
SNAKE_BODY   = (86, 214, 122)
SNAKE_DARK   = (46, 148, 82)
SNAKE_HEAD   = (150, 245, 170)
APPLE_RED    = (222, 62, 60)
APPLE_DARK   = (150, 30, 30)
APPLE_SHINE  = (255, 150, 140)
TEXT_COLOR   = (240, 240, 240)
ACCENT       = (255, 214, 92)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Snake & Apple — Pixel Edition")
clock = pygame.time.Clock()

def load_font(size):
    try:
        return pygame.font.Font(pygame.font.match_font("courier", bold=True), size)
    except Exception:
        return pygame.font.SysFont("courier", size, bold=True)

font_big   = load_font(34)
font_small = load_font(20)

BOARD_TOP = 60


def draw_block(surface, x, y, color_fill, color_shadow, size=CELL):
    rect = pygame.Rect(x, y, size, size)
    pygame.draw.rect(surface, color_fill, rect)
    pygame.draw.rect(surface, color_shadow, rect, width=max(2, size // 8))


def draw_grid():
    screen.fill(BG_DARK)
    for r in range(ROWS):
        for c in range(COLS):
            if (r + c) % 2 == 0:
                pygame.draw.rect(
                    screen, BG_GRID,
                    (c * CELL, BOARD_TOP + r * CELL, CELL, CELL)
                )


def draw_apple(pos):
    x, y = pos[0] * CELL, BOARD_TOP + pos[1] * CELL
    draw_block(screen, x, y, APPLE_RED, APPLE_DARK)
    shine = CELL // 4
    pygame.draw.rect(screen, APPLE_SHINE, (x + 4, y + 4, shine, shine))
    pygame.draw.rect(screen, SNAKE_DARK, (x + CELL // 2 - 2, y - 5, 4, 8))


def draw_snake(snake):
    for i, (sx, sy) in enumerate(snake):
        x, y = sx * CELL, BOARD_TOP + sy * CELL
        if i == 0:
            draw_block(screen, x, y, SNAKE_HEAD, SNAKE_DARK)
        else:
            draw_block(screen, x, y, SNAKE_BODY, SNAKE_DARK)


def draw_score_bar(score, high_score):
    pygame.draw.rect(screen, (10, 12, 16), (0, 0, WIDTH, BOARD_TOP))
    pygame.draw.line(screen, ACCENT, (0, BOARD_TOP - 3), (WIDTH, BOARD_TOP - 3), 3)
    score_txt = font_small.render(f"SCORE {score:03d}", True, TEXT_COLOR)
    high_txt = font_small.render(f"BEST {high_score:03d}", True, ACCENT)
    screen.blit(score_txt, (14, 18))
    screen.blit(high_txt, (WIDTH - high_txt.get_width() - 14, 18))


def random_free_cell(snake):
    while True:
        pos = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
        if pos not in snake:
            return pos


def center_text(text, font, color, y, glow=None):
    surf = font.render(text, True, color)
    rect = surf.get_rect(center=(WIDTH // 2, y))
    if glow:
        glow_surf = font.render(text, True, glow)
        screen.blit(glow_surf, (rect.x + 2, rect.y + 2))
    screen.blit(surf, rect)


def game_over_screen(score, high_score):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    screen.blit(overlay, (0, 0))
    center_text("GAME OVER", font_big, APPLE_RED, HEIGHT // 2 - 40, glow=(60, 0, 0))
    center_text(f"Score: {score}   Best: {high_score}", font_small, TEXT_COLOR, HEIGHT // 2 + 5)
    center_text("Press R to restart or Esc to quit", font_small, ACCENT, HEIGHT // 2 + 40)
    center_text("(You only lose by biting yourself — walls just wrap around!)", font_small, (150, 150, 150), HEIGHT // 2 + 70)


def pause_screen():
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 140))
    screen.blit(overlay, (0, 0))
    center_text("PAUSED", font_big, ACCENT, HEIGHT // 2 - 15)
    center_text("Press P to resume", font_small, TEXT_COLOR, HEIGHT // 2 + 25)


def start_screen(high_score):
    draw_grid()
    draw_score_bar(0, high_score)
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 170))
    screen.blit(overlay, (0, 0))
    center_text("SNAKE & APPLE", font_big, SNAKE_BODY, HEIGHT // 2 - 60, glow=(10, 60, 20))
    center_text("PIXEL EDITION", font_small, ACCENT, HEIGHT // 2 - 22)

    if (pygame.time.get_ticks() // 500) % 2 == 0:
        center_text("Press SPACE or ENTER to Start", font_small, TEXT_COLOR, HEIGHT // 2 + 30)
    center_text("Arrows/WASD to move  |  P to pause", font_small, (150, 150, 150), HEIGHT // 2 + 65)


def new_game():
    snake = [(COLS // 2, ROWS // 2), (COLS // 2 - 1, ROWS // 2), (COLS // 2 - 2, ROWS // 2)]
    direction = (1, 0)
    apple = random_free_cell(snake)
    return snake, direction, apple


STATE_START    = "start"
STATE_PLAYING  = "playing"
STATE_PAUSED   = "paused"
STATE_GAMEOVER = "gameover"


async def main():
    snake, direction, apple = new_game()
    next_direction = direction
    score = 0
    high_score = 0
    fps = FPS_START
    state = STATE_START

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    return

                if state == STATE_START and event.key in (pygame.K_SPACE, pygame.K_RETURN):
                    snake, direction, apple = new_game()
                    next_direction = direction
                    score = 0
                    fps = FPS_START
                    state = STATE_PLAYING

                elif state == STATE_GAMEOVER and event.key == pygame.K_r:
                    snake, direction, apple = new_game()
                    next_direction = direction
                    score = 0
                    fps = FPS_START
                    state = STATE_PLAYING

                elif state in (STATE_PLAYING, STATE_PAUSED) and event.key == pygame.K_p:
                    state = STATE_PAUSED if state == STATE_PLAYING else STATE_PLAYING

                elif state == STATE_PLAYING:
                    if event.key in (pygame.K_UP, pygame.K_w) and direction != (0, 1):
                        next_direction = (0, -1)
                    elif event.key in (pygame.K_DOWN, pygame.K_s) and direction != (0, -1):
                        next_direction = (0, 1)
                    elif event.key in (pygame.K_LEFT, pygame.K_a) and direction != (1, 0):
                        next_direction = (-1, 0)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d) and direction != (-1, 0):
                        next_direction = (1, 0)

        if state == STATE_PLAYING:
            direction = next_direction
            head = (
                (snake[0][0] + direction[0]) % COLS,
                (snake[0][1] + direction[1]) % ROWS,
            )

            if head in snake:
                state = STATE_GAMEOVER
                high_score = max(high_score, score)
            else:
                snake.insert(0, head)
                if head == apple:
                    score += 1
                    apple = random_free_cell(snake)
                    fps = min(FPS_MAX, FPS_START + score // 4)
                else:
                    snake.pop()

        if state == STATE_START:
            start_screen(high_score)
        else:
            draw_grid()
            draw_apple(apple)
            draw_snake(snake)
            draw_score_bar(score, max(high_score, score))

            if state == STATE_PAUSED:
                pause_screen()
            elif state == STATE_GAMEOVER:
                game_over_screen(score, high_score)

        pygame.display.flip()
        clock.tick(fps if state == STATE_PLAYING else 15)
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
